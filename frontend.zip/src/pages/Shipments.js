import Layout from "../components/Layout.";
export default function Shipments(){
    return(
        <Layout>
            Envios
        </Layout>
    );
}